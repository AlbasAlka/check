# MOONTON ACCOUNT CHECKER

Can only be run in python3

## Install

& pkg update && pkg upgrade<br/>
& pkg install python git<br/>
& pip install requests futures bs4<br/>
& git clone https://github.com/AlbasAlka/Checker<br/>
& cd Checker<br/>
& python moonton.py<br/>
